package com.example.gamecatalogservice.resource;

import com.example.gamecatalogservice.models.CatalogItem;
import com.example.gamecatalogservice.models.Game;
import com.example.gamecatalogservice.models.UserRating;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/catalog")
public class GameCatalogResource {
    @Autowired
    private RestTemplate restTemplate;

//    @Autowired
//    private WebClient.Builder webClientBuilder;

    @RequestMapping("/{userId}")
    public List<CatalogItem> getCatalog(@PathVariable("userId") String userId){

//            WebClient.Builder builder = WebClient.builder();
//            RestTemplate restTemplate = new RestTemplate();

            UserRating ratings = restTemplate.getForObject("http://ratings-game-data-service/ratingsdata/users" + userId, UserRating.class);
//            = Arrays.asList(
//                    new Rating("1234", 5),
//                    new Rating("5678", 2)
//            );

            return ratings.getUserRating().stream().map(rating ->{
//            restTemplate.getForObject("http://localhost:8092/ratingsdata/" + rating.getBookId(), Rating.class);

                Game game = restTemplate.getForObject("http://game-info-service/games/" + rating.getGameId(), Game.class);

                return new CatalogItem(game.getName(), "", rating.getRating());
            })
                    .collect(Collectors.toList());

    }

}
