package com.example.ratingsdataservice;

import com.example.ratingsdataservice.models.Rating;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/ratingsdata")
public class RatingsResource {


        @RequestMapping("/{bookId}")
        public Rating getRating(@PathVariable("bookId") String bookId){
            return new Rating(bookId, 10);

        }

}
