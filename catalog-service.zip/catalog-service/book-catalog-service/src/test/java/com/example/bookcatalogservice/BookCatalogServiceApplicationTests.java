package com.example.bookcatalogservice;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class BookCatalogServiceApplicationTests {

	@Test
	public void contextLoads() {
	}

}
